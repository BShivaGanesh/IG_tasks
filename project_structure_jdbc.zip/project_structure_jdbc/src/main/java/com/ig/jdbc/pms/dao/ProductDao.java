package com.ig.jdbc.pms.dao;

import com.ig.jdbc.pms.model.Product;
import java.util.List;

public interface ProductDao {
	public void addProduct(Product p) throws Exception;
	public List<Product> getAllProducts() throws Exception;
	public Product getProductById(Integer id) throws Exception;
	public boolean deleteProductById(Integer id) throws Exception;
	public boolean updateProductById(Integer id , String new_name) throws Exception;

}
