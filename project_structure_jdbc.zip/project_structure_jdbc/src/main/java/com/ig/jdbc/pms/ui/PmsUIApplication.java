package com.ig.jdbc.pms.ui;

import java.util.Scanner;

import com.ig.jdbc.pms.model.Product;
import com.ig.jdbc.pms.service.ProductService;
import com.ig.jdbc.pms.service.ProductServiceImpl;

public class PmsUIApplication {
	public static void main(String[] args) throws Exception{
		ProductService productService = new ProductServiceImpl();
		Scanner sc = new Scanner(System.in);
//		System.out.println("Enter product details:");
//		Product p = new Product();
//		p.setId(sc.nextInt());
//		sc.nextLine();
//		p.setName(sc.nextLine());
//		productService.addProduct(p);
		
		System.out.println("Getting all the products");
		productService.getAllProducts().forEach(x -> System.out.println(x));
		
//		System.out.println("Enter product id to get the product: ");
//		System.out.println(productService.getProductById(sc.nextInt()));
//		
//		System.out.println("Enter product id to delete the product: ");
//		System.out.println(productService.deleteProductById(sc.nextInt()));
		
		System.out.println("Enter product id to update: ");
		Integer id = sc.nextInt();
		sc.nextLine();
		String new_name = sc.nextLine();
		
		System.out.println(productService.updateProductById(id,new_name));
		
		System.out.println("Getting all the products");
		productService.getAllProducts().forEach(x -> System.out.println(x));
		
	}

}
