package com.ig.jdbc.pms.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.ig.jdbc.pms.exception.ProductNotFoundException;
import com.ig.jdbc.pms.model.Product;
import com.ig.jdbc.pms.util.DbUtil;

public class ProductDaoImpl implements ProductDao{
	public void addProduct(Product product) throws Exception{
		Connection con =  DbUtil.getConnection();
		PreparedStatement pst = con.prepareStatement("insert into product values(?,?)");
		pst.setInt(1, product.getId());
		pst.setString(2,product.getName());
		pst.execute();
	}
	
	public List<Product> getAllProducts() throws Exception{
		ArrayList<Product> pList = new ArrayList<>();
		Connection con = DbUtil.getConnection();
		Statement st = con.createStatement();
		ResultSet rs = ((java.sql.Statement) st).executeQuery("select * from product");
		while(rs.next()) {
			Product p = new Product();
			p.setId(rs.getInt(1));
			p.setName(rs.getString(2));
			pList.add(p);
		}
		return pList;
		
	}

	
	
	public Product getProductById(Integer id) throws Exception{
		Connection con = DbUtil.getConnection();
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("select * from product where id="+id);
		if(rs.next()) {
		Product p = new Product();
		p.setId(rs.getInt(1));
		p.setName(rs.getString(2));
		return p;
		}
		else {
			throw new ProductNotFoundException("No product with that id");
		}
	}

	public boolean deleteProductById(Integer id) throws Exception{
		Connection con = DbUtil.getConnection();
		Statement st = con.createStatement();
		 
		 return st.executeUpdate("Delete from product where id="+id)>0;
		 
//		 or
//		PrepareStatement pst = con.prepareStatement("DELETE FROM product WHERE id = ?");
//	        pst.setInt(1, id);
//	        return pst.executeUpdate() > 0;		
	}

	@Override
	public boolean updateProductById(Integer id , String new_name) throws Exception {
		// TODO Auto-generated method stub
		Connection con = DbUtil.getConnection();
		//Statement st = con.createStatement();
		//return st.executeUpdate("Update product set name = '"+new_name +"' where id="+id)>0;
	PreparedStatement pst = con.prepareStatement("Update product set name = ? where id = ?");
		 
		 pst.setString(1,new_name);
		 pst.setInt(2,id);
		 return pst.executeUpdate()>0;
	}

}
