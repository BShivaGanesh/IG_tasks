package com.ig.jdbc.pms.exception;

public class ProductNotFoundException extends Exception{
	public ProductNotFoundException( String msg){
		super(msg);
	}

}
