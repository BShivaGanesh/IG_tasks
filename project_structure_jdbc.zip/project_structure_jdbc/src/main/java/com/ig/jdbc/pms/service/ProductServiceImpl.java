package com.ig.jdbc.pms.service;

import java.util.List;

import com.ig.jdbc.pms.dao.ProductDao;
import com.ig.jdbc.pms.dao.ProductDaoImpl;
import com.ig.jdbc.pms.exception.ProductNotFoundException;
import com.ig.jdbc.pms.model.Product;

public class ProductServiceImpl implements ProductService{
	ProductDao productDao;
	public void addProduct(Product p) throws Exception{
		productDao = new ProductDaoImpl();
		productDao.addProduct(p);
		
	}
	
	public List<Product> getAllProducts()throws Exception{
		productDao = new ProductDaoImpl();
		return productDao.getAllProducts();
	}
	
	public Product getProductById(Integer id) throws Exception{
		productDao = new ProductDaoImpl();
		return productDao.getProductById(id);
	}

	@Override
	public boolean deleteProductById(Integer id) throws Exception {
		productDao = new ProductDaoImpl();
		if(productDao.deleteProductById(id)) {
			System.out.println("Deleted successfully");
		return productDao.deleteProductById(id);
		}
		else {
			throw new ProductNotFoundException("Product not found");
		}
	}

	@Override
	public boolean updateProductById(Integer id, String new_name) throws Exception {
		productDao = new ProductDaoImpl();
		if(productDao.updateProductById(id,new_name)) {
			System.out.println("Deleted successfully");
		return productDao.updateProductById(id,new_name);
		}
		else {
			throw new ProductNotFoundException("Product not found");
		}
	}
	
	

}
