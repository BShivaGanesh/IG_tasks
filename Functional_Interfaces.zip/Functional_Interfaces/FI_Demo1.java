package Functional_Interfaces;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.function.Predicate;

// custom functional interface
interface Arithmetic<T>{
	T op(T a, T b);
}

public class FI_Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Arithmetic<Integer> i = (a,b)-> a+b;
		System.out.println(i);
		System.out.println(i.op(6, 8));
		Arithmetic<Long> i1 = (a,b)-> a*a+b*b;
		System.out.println(i1);
		System.out.println(i1.op(3l, 1l));
		
		//inbuilt functional interfaces
		
		Consumer<Integer> c = (x)-> System.out.println(x*x*x);
		c.accept(4);
		
		Supplier<Integer> s = ()-> 99;
		System.out.println(s.get());
		
		Function<Integer,Integer>f = (x)-> x*x;
		System.out.println(f.apply(4));
		
		Predicate<Integer> p = (x)-> x%2 == 0 ;
		System.out.print(p.test(4));
		

	}

}
