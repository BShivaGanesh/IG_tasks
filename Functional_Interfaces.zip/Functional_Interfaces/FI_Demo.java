package Functional_Interfaces;

interface Calculator {
	int op(int a , int b);
}

public class FI_Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calculator c = (a,b)->a+b;
//		System.out.println(c);
		System.out.println(c.op(3, 4));
		Calculator c1 = (a,b)->a-b;
		System.out.println(c1.op(3, 4));
		

	}

}
