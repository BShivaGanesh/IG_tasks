package Functional_Interfaces;

interface Arith{
	int add(int a , int b);
	
	static void disp() {
		System.out.println("Arith disp method");
	}
	
	default void show() {
		System.out.println("Arith show default method");
	}
	
	default int product(int a , int b) {
		return a*b;
	}
	
}


public class Interface_Demo implements Arith{
	@Override
	public int add(int a, int b) {
		// TODO Auto-generated method stub
		return a+b;
	}
	
	public void show() {
		System.out.println("child show default method");
	}
	
	public void call_parent_methods() {
		Arith.super.show();
		System.out.println("Arith product method result: "+Arith.super.product(3, 4));
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Arith a = new Interface_Demo();
		System.out.println(a.add(3, 4));
		a.show();
		Interface_Demo a1 = new Interface_Demo();
		System.out.println("interface methods:");
		Arith.disp();
		a1.call_parent_methods();
		
	}
}
