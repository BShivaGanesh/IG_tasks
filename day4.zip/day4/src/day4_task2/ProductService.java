package day4_task2;
import java.util.*;

class ProductService{
	List<Product> plist;
	public ProductService(List<Product> plist) {
		this.plist = plist;
	}
	Double getPricebyId(Integer id){
		for(Product p : plist) {
			if(p.id.equals(id)) {
				return p.price;
			}
		}
		return null;
		
	}
	
	Product getProductById(Integer id) {
		for(Product p : plist) {
			if(p.id.equals(id)) {
				return p;
			}
		}
		return null;
		
	}
	void listProducts(){
		plist.forEach(x->System.out.println(x)); 
	}
}
