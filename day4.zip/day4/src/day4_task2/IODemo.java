
package day4_task2;
import java.util.*;
import java.io.*;

public class IODemo {

    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);
        FileReader f1 = new FileReader("C:/Users/ShivaganeshBoggarapu/Desktop/products.txt");
        BufferedReader b = new BufferedReader(f1);
   
        List<Product> plist = new ArrayList<>();
        
        String line;
        while ((line = b.readLine()) != null) {
            String[] data = line.split(",");
            Integer id = Integer.parseInt(data[0].trim());
            String name = data[1].trim();
            Integer qty = Integer.parseInt(data[2].trim());
            Double price = Double.parseDouble(data[3].trim());
            plist.add(new Product(id, name, qty, price));
        }

        ProductService ps = new ProductService(plist);
        boolean checker = true;
		while(checker) {
	    System.out.println("Options : ");
	    System.out.println("1. get price");
		System.out.println("2. get product");
		System.out.println("3. get all products");
		System.out.println("4. exit");
		System.out.println("Enter your choice:");
		Integer choice = sc.nextInt();
		 Integer idToCheck;
		
		switch(choice){
		case 1:
			System.out.println("Enter product id to get its price:");
	         idToCheck = sc.nextInt();
	        System.out.println("Price of product with ID " + idToCheck + ": " + ps.getPricebyId(idToCheck));
	        break;
		case 2:
			System.out.println("Enter product id to get the product details:");
	         idToCheck = sc.nextInt();
	        System.out.println("Product details: " + ps.getProductById(idToCheck));
	        break;
		case 3:
			 System.out.println("All products:");
		     ps.listProducts();
		     break;
		 case 4 :
         	checker = false;
         	break;
         default :
         	System.out.println("Enter a valid choice");

			
		}
        
		}  
    }
}
