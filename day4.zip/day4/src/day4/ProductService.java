package day4;
import java.util.*;

public class ProductService {
	
	static List<Product> plist=new ArrayList<>();
	
	public String addProduct(Product p) {
		plist.add(p);
		return "success";
		
	}
	public String deleteProduct(Integer id) {
        Product productToRemove = null;
        for (Product product : plist) {
            if (product.id.equals(id)) {
                productToRemove = product;
                break;
            }
        }

        if (productToRemove != null) {
            plist.remove(productToRemove);
            return "Product deleted successfully";
        } else {
            return "Product not found";
        }
    }
	 public String updateProduct(Integer id, String newName) {
        for (Product product : plist) {
            if (product.id.equals(id)) {
                product.name = newName;
                return "Product updated successfully";
            }
        }
        return "Product not found";
    }
    	public Product getProduct(Integer id) {
    	    for(Product p : plist){
    	        if(p.id.equals(id)){
    	            return p;
    	        }
    	    }
    	    return null;
	    
	}
	public void  listProducts(){
		plist.forEach(x->System.out.println(x));
	}

}

