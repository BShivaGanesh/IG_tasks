package day4;
import java.util.*;

public class ProductTest {

	public static void main(String[] args) {
		ProductService ps=new ProductService();
		Integer id;
		String name;
		Product product;
		String result;
		Scanner sc = new Scanner(System.in);
		boolean checker = true;
		while(checker) {
	    System.out.println("Options : ");
	    System.out.println("1. add product");
		System.out.println("2. update product");
		System.out.println("3. delete product");
		System.out.println("4. get product");
		System.out.println("5. get all products");
		System.out.println("6. exit");
		System.out.println("Enter your choice : ");
		Integer choice = sc.nextInt();
		
		switch(choice){
		    case 1 : 
		        System.out.print("Enter product id: ");
                 id = sc.nextInt();
                sc.nextLine(); 
                System.out.print("Enter product name: ");
                 name = sc.nextLine();
                 product = new Product(id, name);
                 result = ps.addProduct(product);
                System.out.println(result);
                break;
		    case 2 :
		        System.out.println("Enter product id to update:");
		         id = sc.nextInt();
		        sc.nextLine();
		        System.out.println("Enter new name for the product");
		         name = sc.next();
		         product = new Product(id, name);
		         result = ps.updateProduct(id, name);
		        System.out.println(result);
		        break;
		        
		
		    case 3 :
		        System.out.println("Enter product id to delete:");
		         id = sc.nextInt();
		        sc.nextLine();
		         result = ps.deleteProduct(id);
		         System.out.println(result);
		        break;
		    case 4 : 
		         System.out.println("Enter product id to get: ");
                  id = sc.nextInt();
                 Product productById = ps.getProduct(id);
                 if (productById != null) {
                    System.out.println("Product found: " + productById);
                 } else {
                    System.out.println("Product not found.");
                }
                break;
            case 5:
                ps.listProducts();
                break;
            case 6 :
            	checker = false;
            	break;
            default :
            	System.out.println("Enter a valid choice");
		}
		
		}
	}

}
