package Streams;

public class CandidateStreamingOperations1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 System.out.println("List of Pune Candidates:");
		 InterviewRepository.getCandidateList().stream()
		 .filter(candidate -> "Pune".equals(candidate.getCity()))
		 .map(Candidate :: getName)
		 .forEach(System.out::println);
		 
		 // List city and count of candidates per city
//	        System.out.println("Candidate count per city");
//	       Map<String,Long>m = InterviewRepository.getCandidateList().stream()
//	        .collect(Collector.)
		 
		  // List fresher candidates
	        System.out.println("Fresher Candidate list");
	        InterviewRepository.getCandidateList().stream()
	        .filter(candidate -> candidate.getCount()==0)
	        .forEach(System.out::println);
	        

	}

}
