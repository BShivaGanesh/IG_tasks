package Streams;
import java.util.*;
import java.util.stream.Collectors;

public class CarServiceImpl implements CarService{
	
    public double sumOfPrices(List<Car> carList) {
        return carList.stream()
                .mapToDouble(Car::getPrice)
                .sum();
    }

    public List<String> getCarNames(List<Car> carList) {
        return carList.stream()
                .map(Car::getCarName)
                .collect(Collectors.toList());
    }

    public List<String> getCarMakers(List<Car> carList) {
        return carList.stream()
                .map(Car::getCareMake)
                .distinct()
                .collect(Collectors.toList());
    }

    public double getHighPricedCar(List<Car> carList) {
        return carList.stream()
                .max(Comparator.comparingDouble(Car::getPrice))
                .map(Car::getPrice)
                .orElse(0.0); 
    }

    public Car getCarWithLowPricedCar(List<Car> carList) {
        return carList.stream()
                .min(Comparator.comparingDouble(Car::getPrice))
                .orElse(null); 
    }

}
