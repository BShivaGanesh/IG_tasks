package Streams;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ProductService {
	 private List<Product> products;

	    public ProductService(List<Product> products) {
	        this.products = products;
	    }
	    
	    private static void printLine() {
	        System.out.println("======================================================");
	    }
	    
	    public Product getHighestPricedProduct() {
	    	return products.stream()
	    			.max(Comparator.comparingDouble(Product :: getPrice)).orElse(null);
	    }
	    
	    public Product getLowestPricedProduct() {
	    	return products.stream()
	    			.min(Comparator.comparingDouble(Product :: getPrice)).orElse(null);
	    }
	    
	    public List<Product> getExpiredProducts(){
	    	LocalDate today = LocalDate.now();
	    	return products.stream()
	    			.filter(product -> product.getExpiryDate().isBefore(today))
	    			.collect(Collectors.toList());
	    }
	    
	    public List<Product> getExpiredProductsInTenDays(){
	    	LocalDate today = LocalDate.now();
	    	LocalDate ten = today.plusDays(10);
	    	return products.stream()
	    			.filter(product -> !product.getExpiryDate().isBefore(today) && product.getExpiryDate().isBefore(ten))
	    			.collect(Collectors.toList());
	    }
	    
	    public Map<String,Long> getProductOccurence(){
        	return products.stream()
        			.collect(Collectors.groupingBy(Product::getType, Collectors.counting()));
	    }
	    
	    
	public static void main(String[] args) {
		List<Product> productList = Arrays.asList(
	            new Product(1, "Milk", "dairy", 10.0, 50.0, LocalDate.of(2025, 3, 1)),
	            new Product(2, "Rice", "pulses", 20.0, 30.0, LocalDate.of(2025, 4, 15)),
	            new Product(3, "Oil", "oils", 15.0, 70.0, LocalDate.of(2025, 2, 25)),
	            new Product(4, "Spices", "spices", 5.0, 20.0, LocalDate.of(2025, 3, 5)),
	            new Product(5, "Chips", "snacks", 10.0, 10.0, LocalDate.of(2025, 3, 10))
	        );

	        ProductService productService = new ProductService(productList);
	        
	        printLine();
	        
	        System.out.println("Highest priced product: " + productService.getHighestPricedProduct());
	        
	        printLine();
	        
	        System.out.println("Lowest priced product: " + productService.getLowestPricedProduct());
	        
	        printLine();
	        
	        System.out.println("List of products which are expired already : " + productService.getExpiredProducts());
	        
	        printLine();
	        
	        System.out.println("List of products which are expiring in 10 days : " + productService.getExpiredProductsInTenDays());
	        
	        printLine();
	        
	        System.out.println("Getting products occurences: " +productService.getProductOccurence());
	        
	               
	        
	}

}
