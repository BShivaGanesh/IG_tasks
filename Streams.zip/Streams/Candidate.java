package Streams;

public class Candidate {
	String name;
	String language;
	String city;
	Integer count;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	public Candidate(String name, String language, String city, Integer count) {
		super();
		this.name = name;
		this.language = language;
		this.city = city;
		this.count = count;
	}
	@Override
	public String toString() {
		return "Candidate [name=" + name + ", language=" + language + ", city=" + city + ", count=" + count + "]";
	}
	

}
