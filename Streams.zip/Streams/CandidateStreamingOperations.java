package Streams;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class CandidateStreamingOperations {

    public static void main(String[] args) {
        
        // List candidate names from Pune city
        System.out.println("List of Pune Candidates:");
        InterviewRepository.getCandidateList().stream()
                .filter(candidate -> "Pune".equals(candidate.getCity()))
                .map(Candidate::getName)
                .forEach(System.out::println);
        
        printLine();
        
        // List city and count of candidates per city
        System.out.println("Candidate count per city");
        Map<String, Long> map1 = InterviewRepository.getCandidateList().stream()
                .collect(Collectors.groupingBy(Candidate::getCity, Collectors.counting()));
        map1.forEach((city, count) -> System.out.println(city + ": " + count));
        
        printLine();
        
        // List technical expertise and count of candidates
        System.out.println("Candidate count by Technical Expertise");
        Map<String, Long> map2 = InterviewRepository.getCandidateList().stream()
                .collect(Collectors.groupingBy(Candidate::getLanguage, Collectors.counting()));
        map2.forEach((language, count) -> System.out.println(language + ": " + count));
        
        printLine();
        
        // List fresher candidates
        System.out.println("Fresher Candidate list");
        InterviewRepository.getCandidateList().stream()
                .filter(candidate -> candidate.getCount() == 0)
                .forEach(System.out::println);
        
        printLine();
        
        // Listing candidates with highest experience
        System.out.println("Sorted List of Candidates by Experience");
        InterviewRepository.getCandidateList().stream()
                .sorted(Comparator.comparingInt(Candidate::getCount).reversed())
                .forEach(System.out::println);
        
        printLine();
        
        // Sort the candidates by city name
        System.out.println("Sorted List of Candidates by City Name");
        InterviewRepository.getCandidateList().stream()
                .sorted(Comparator.comparing(Candidate::getCity))
                .forEach(System.out::println);
        
        printLine();
        
        //max experience candidate
       Integer max =  InterviewRepository.getCandidateList().stream()
    		   .map(candidate -> candidate.getCount())
        .max(Integer::compare).get();
       System.out.println(max +":MAX");
    }
    
    
    

    private static void printLine() {
        System.out.println("======================================================");
    }
}
