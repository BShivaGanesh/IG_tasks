package Streams;

import java.util.*;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MAX_MIN_AVG_Demo {
	static String checkPalindrome(String word) {
		StringBuilder sb= new StringBuilder(word);
		return sb.reverse().toString();
		
	}
	
	private static void printLine() {
        System.out.println("======================================================");
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		printLine();
		List<Integer>list = Arrays.asList(-9,-18,10,0,6,78);
		Integer min = list.stream()
						.min(Integer :: compare)
						.get();
		System.out.println("Minimum: " + min);
		printLine();
		Integer max = list.stream().max(Integer :: compare ).get();
		System.out.println("maximum: " + max);
		printLine();
		
		Stream<String> s= Stream.of("3","4","5");
		double avg = s.collect(Collectors.averagingDouble(num -> Double.parseDouble(num)));
		System.out.println("Average: " + avg);
		printLine();
		
		//display list of numbers starting with 1
		System.out.println("Printing numbers starting with 1:");
		List<Integer>l=Arrays.asList(20,30,11,18,29,1,123,198);
		l.stream().filter(num->String.valueOf(num)
				.startsWith("1"))
		.forEach(System.out::println);
		
		printLine();
		
		//need to extract the count of occurrences of each character in a string using string
		System.out.println("Getting the character count from given string: ");
		String name = "insightglobal";
		 Map<Character, Long> map = name.chars() 
		            .mapToObj(c -> (char) c) 
		            .collect(Collectors.groupingBy(c -> c, Collectors.counting()));  
		 
		System.out.println(map);
		
		printLine();
		
		//display lowest length of palindrome from list using streams
		System.out.println("Getting the palindrome which has min length: ");
		List<String> palindromeList = Arrays.asList("madam","liril","aba","apple","ba");
		Comparator<String>st = (s1,s2)-> s1.length()-s2.length();
		palindromeList.stream()
		.filter(word -> checkPalindrome(word).equals(word))
		.sorted(st)
		.limit(1)
		.forEach(System.out::println);
		
		printLine();
		
		

	}
	

}
