package testing;

public class Arith {

	public Integer add(int i, int j) {
		
		return i+j;
	}

}
