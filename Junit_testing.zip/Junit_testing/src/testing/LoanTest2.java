package testing;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

/*using life cycle methods only one object is created and initialized in 
@beforeEach-: this method is executed for every test method in the test class
and the object is initialized in this and then, deallocated in
 @afterEach-: this method is called for every test method in the test class and the object is
  deallocated after the method implementation is done
*/

class LoanTest2 {
	Loan l;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		//executed once - db connections
		System.out.println("before all");
		
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		System.out.println("after all");
	}

	@BeforeEach
	void setUp() throws Exception {
		System.out.println("before each");
		l = new Loan();
	}

	@AfterEach
	void tearDown() throws Exception {
		System.out.println("after each");
		l=null;
	}

	@Test
	void testGetEmi() {
		assertEquals(5000,l.getEmi(60000));
		//fail("Not yet implemented");
	}

	@Test
	void testSum() {
		assertEquals(7,l.sum(3,4));
		//fail("Not yet implemented");
	}
	@Test
	void testDivide() {
		assertEquals(2,l.divide(10,5));
		//fail("Not yet implemented");
	}
	
	//writing test case for handling built-in exception
	@Test
	void testDivide1() {
		ArithmeticException e = assertThrows(ArithmeticException.class , ()->{
			l.divide(10, 0);
		});
		assertEquals("/ by zero", e.getMessage());
		//handling custom exception in test case
		MyException e1 = assertThrows(MyException.class , ()->{
			l.deposit();
		});
		assertEquals("sample custom exception",e1.getMessage());
	}
	//we can handle two exceptions in one test case as shown above
	//handling custom exception test case separately
	@Test
	void testDeposit() {
		MyException e1 = assertThrows(MyException.class , ()->{
			l.deposit();
		});
		assertEquals("sample custom exception",e1.getMessage());
	}
	
	@ParameterizedTest
	@ValueSource(ints = {1,3,5,15,17,22,25,27,89,2342,32})
	void ifEvenOrOddTest(Integer num) {
		assertTrue(num%2!=0);
	}

}
