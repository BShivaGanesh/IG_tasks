package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ArithTest {

	@Test
	void test() {
		Arith a = new Arith();
		assertEquals(10,a.add(3,7));
		//fail("Not yet implemented");
	}

}
