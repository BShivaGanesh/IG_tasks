package testing;

public class Loan {
	int getEmi(int amt) {
		return amt/12;
	}
	int sum(int a , int b) {
		return a+b;
	}
	int divide(int a , int b) {
		return a/b;
	}
	
	public void deposit() throws MyException{
		throw new MyException("sample custom exception");
	}

}
