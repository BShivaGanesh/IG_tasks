package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
/* this is without life cycle methods where for every method we need to create an object 
 * and call that method with different values for testing the code in different ways
 * and store that value in a variable and we have to cross check 
 * with the original value and expected value by using assert library methods.
 * */

class LoanTest {

	@Test
	void testGetEmi() {
		Loan l = new Loan();
		int res = l.getEmi(60000);
		assertEquals(5000,res);
		
		//assertEquals(expected value , actual output)-if both are same then the  test case will be passes
		
		//fail("Not yet implemented");
	}

	@Test
	void testSum() {
		Loan l = new Loan();
		int res = l.sum(3, 4);
		assertEquals(7,res);
		//fail("Not yet implemented");
	}
	
	@Test
	void testDivide() {
		Loan l = new Loan();
		int res = l.divide(10, 5);
		assertEquals(2,res);
		//fail("Not yet implemented");
	}
	
	@Test
	void testDivide1() {
		Loan l = new Loan();
		ArithmeticException e = assertThrows(ArithmeticException.class , ()->{
			l.divide(10, 0);
		});
		//handling custom exception in test case
		MyException e1 = assertThrows(MyException.class , ()->{
			l.deposit();
		});
	}

}
