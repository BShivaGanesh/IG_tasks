package task;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class VoterValidatorTest {
	VoterValidator v;

	@Test
public	void testValidateVoterAge() throws Exception{
		v= new VoterValidator();
		Exception e = assertThrows(Exception.class , ()->{
			v.validateVoterAge(-1);
		});
		    
		    assertEquals("Invalid age", e.getMessage());
		  
	    }
	
//	@ParameterizedTest
//	@ValueSource(ints = { 19,20,45,78})
//	public void validateVoterAgeTestParameter123(int age) throws Exception {
//		
//		Assertions.assertTrue();
//	}
}