package day5;

public class stack {
	 private Contact[] stackArray;
	    private int maxSize;
	    private int top;

	  
	    public stack(int size) {
	        this.maxSize = size;
	        this.stackArray =  new Contact[size];
	        this.top = -1;

}

	    public void push(Contact value) throws MemoryFullException {
	        if (top > maxSize) {
	            throw new MemoryFullException("Stack is full. Cannot push " + value);
	        }
	        stackArray[++top] = value;
	    }

	    public Contact pop() throws StackEmptyException {
	        if (top == -1) {
	            throw new StackEmptyException("Stack is empty. Cannot pop.");
	        }
	        return stackArray[top--];
	    }
}
