package day5;
import java.util.Scanner;

public class StackOp{

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter stack size: ");
		Integer n = sc.nextInt();
		stack s = new stack(n);
		try {
			Contact c1 =  new Contact("boggarapu" , "shiva" , "ganesh" , "22/09/2003" , "Male" , "9848870116");
			s.push(c1);
			Contact c2 =  new Contact("m" , "p" , "r" , "29/08/2003" , "Male" , "9848870116");
			s.push(c2);
			s.pop();
		
		}
		catch(MemoryFullException | StackEmptyException e) {
			System.out.println(e);
		}
	}

}


