package day5;

public class StackEmptyException extends Exception {
	StackEmptyException(String msg){
		super(msg);
	}
}
