package day5;

public class MemoryFullException extends Exception{
	MemoryFullException(String msg){
		super(msg);
	}

}
