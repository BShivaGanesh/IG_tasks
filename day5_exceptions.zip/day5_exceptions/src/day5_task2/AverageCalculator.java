package day5_task2;

public class AverageCalculator {
	public double calAverage(int n) throws IllegalArgumentException{
		if(n > 0) {
		int sum=0;
		for(int i=1;i<n ; i++) {
			sum+=i;
		}
		double avg = sum/n;
		return avg;
		}
		else {
			throw new IllegalArgumentException("Enter only a natural number");
		}
	}

}
