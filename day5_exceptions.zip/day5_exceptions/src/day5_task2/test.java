package day5_task2;

public class test  {
	public static void main(String[] args) throws IllegalArgumentException{
		AverageCalculator obj = new AverageCalculator();
		obj.calAverage(0);
	}

}
