package day5_task2;

public class IllegalArgumentException extends Exception{
	IllegalArgumentException(String msg){
		System.out.println(msg);
	}

}
