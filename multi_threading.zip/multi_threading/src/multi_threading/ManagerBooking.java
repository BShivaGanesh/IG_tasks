package multi_threading;

class Room extends Thread{
	boolean isAvailable;
	Room(){
		this.isAvailable = true;
	}
	synchronized boolean checkAvailability() {
		return isAvailable;
	}
	synchronized void bookRoom() {
		if(isAvailable) {
			isAvailable=false;
			System.out.println(Thread.currentThread().getName() +": has booked the room");
		}
	}
	 
}

class CoferenceBookingJob extends Thread{
	Room r;
	CoferenceBookingJob(Room r){
		this.r = r;
		this.start();
	}	
	public void run() {
	if(r.checkAvailability()) {
		r.bookRoom();
	}
	else {
		System.out.println("No rooms left");
	}
	}
	
}

public class ManagerBooking extends Thread  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Room r = new Room();
		CoferenceBookingJob m1 = new CoferenceBookingJob(r);
		
		CoferenceBookingJob m2 = new CoferenceBookingJob(r);
		CoferenceBookingJob m3 = new CoferenceBookingJob(r);

	}

}
