package multi_threading;

class ConferenceRoom{
	static boolean flag = true;
	public  void conferenceRoomBookingJob() {
		if(flag) {
			flag = false;
			System.out.println(Thread.currentThread().getName() +" :Successfully booked");
			//flag=true;
		}
		else {
			System.out.println("No conference rooms left");
		}
		
	}
}

public class Manager extends Thread{
	ConferenceRoom c;
	
	Manager(ConferenceRoom c){
		this.c=c;
		this.start();
		try {
			this.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void run() {
		c.conferenceRoomBookingJob();
	}

	public static void main(String[] args) {
		ConferenceRoom c = new ConferenceRoom();
		
		Manager m1 = new Manager(c);
		Manager m2 = new Manager(c);

	}

}



