package multi_threading;

public class ThreadDemo2 implements Runnable{
	public void run() {
		System.out.println(Thread.currentThread().getName());
	}
	public static void main(String[] args) {
		System.out.println(Thread.currentThread().getName());
		ThreadDemo2 t1 = new ThreadDemo2();
		Thread t = new Thread(t1);
		t.start();
		System.out.println("Number of active threads: "+Thread.activeCount());
	}

}
