package multi_threading;
import java.util.Random;
import java.util.Random.*;

public class Advisor extends Thread{
	String[] arr = {
	"Never begin to stop and never stop to begin.",
	 "Only destination isn’t important, one should enjoy the journey.",
	"impossible itself says ‘i m possible’"	
	};
	public void run() {
		Random r= new Random();
		int idx=r.nextInt(arr.length);
		System.out.println(arr[idx]);	
	}
	public static void main(String[] args) {
		Advisor a = new Advisor();
		a.start();
	}

}
