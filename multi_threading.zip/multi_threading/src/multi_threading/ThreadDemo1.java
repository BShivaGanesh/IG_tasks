package multi_threading;

public class ThreadDemo1 extends Thread{
	public void run() {
		System.out.println(Thread.currentThread().getName());
		}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Thread.currentThread().getName());
		ThreadDemo1 t1 = new ThreadDemo1();
		t1.start();
		t1.setName("java1");
		ThreadDemo1 t2 = new ThreadDemo1();
		t2.start();
		t2.setName("java2");
		System.out.println("Number of active threads: "+Thread.activeCount());
		
		try {
			//join method makes threads ready for garbage collection 
			t1.join();
			t2.join();
		}
		catch(InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Number of active threads: "+Thread.activeCount());

	}

}
