package multi_threading;

class Caller{
//	public synchronized void call(String s) { //method level synchronization
	public  void call(String s) {
		synchronized(this) { //block level synchronization
		try {
		System.out.print("welcome to Mr./Mrs. ");
		Thread.sleep(1000);
		System.out.println(s);
		System.out.println("Good morning");
		}
		
		catch(InterruptedException e) {
			e.printStackTrace();
		}
		}
		
	}
}

public class SyncDemo extends Thread{
	Caller c;
	String s;
	SyncDemo(Caller c, String s){
		this.c=c;
		this.s=s;
		this.start();
	}
	public void run() {
		c.call(s);
	}

	public static void main(String[] args) {
		Caller c = new Caller();
		//at same time 3 threads are accessing same object i.e.., "c" so leads to false results ~ RACE CONDITION
		//to avoid this race condition we do SYNCHRONIZATION 
		SyncDemo s1 = new SyncDemo(c,"user1");
		SyncDemo s2 = new SyncDemo(c,"user2");
		SyncDemo s3 = new SyncDemo(c,"user2");

	}

}
