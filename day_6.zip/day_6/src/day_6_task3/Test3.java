package day_6_task3;
import java.util.Scanner;

import java.util.regex.*;

public class Test3 {

    public static boolean validatePAN(String pan) {
        String regex = "^[A-Z]{3}\\d{4}[A-Z]$";
        Pattern pattern = Pattern.compile(regex);
        System.out.println(pattern);
        Matcher matcher = pattern.matcher(pan);
        System.out.println(matcher);
        return matcher.matches();
    }

    public static void main(String[] args) {
    	Scanner sc = new Scanner(System.in);
    	System.out.println("Enter your pan number:");
    	String pan = sc.next();
        System.out.println(validatePAN(pan) ? "Valid" : "Invalid");
    }
}

