package day_6_task3;

import java.util.Scanner;

import java.util.Scanner;

public class Test4 {
    public static String reshape(String str, char c) {
        String rev = new StringBuilder(str).reverse().toString();
        StringBuilder res = new StringBuilder();
        for (int i = 0; i < rev.length(); i++) {
            res.append(rev.charAt(i));
            if (i < rev.length() - 1) {
                res.append(c);
            }
        }
        return res.toString();
    }

    public static void main(String[] args) {
       
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String str = sc.nextLine();
        System.out.print("Enter a character: ");
        char c = sc.next().charAt(0);
        String finalString = reshape(str, c);
        System.out.println("Final Result: " + finalString);
    }
}

