package day_6_task3;
import java.util.*;

public class Test5 {
    public static String getLastLetter(String sentence) {
        String[] words = sentence.split(" "); 
        StringBuilder result = new StringBuilder(); 
        for (String word : words) {
            if (!word.isEmpty()) { 
                result.append(Character.toUpperCase(word.charAt(word.length() - 1)));
            }
        }

        return result.toString(); 
    }

    public static void main(String[] args) {
    	Scanner sc = new Scanner(System.in);
    	System.out.println("Enter sentence :");
        String sentence = sc.nextLine();
        String finalString = getLastLetter(sentence);
        System.out.println("Final String: " + finalString);
    }
}
