package day_6_task3;

import java.util.Scanner;

public class Test7 {
    public static String convertFormat(String input) {
        String number = input.replace("-", "");
        String formattedNumber = number.substring(0, 2) + "-" + 
                                 number.substring(2, 4) + "-" + 
                                 number.substring(4, 7) + "-" + 
                                 number.substring(7, 10);
        
        return formattedNumber;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a 10-digit number in the format XXX-XXX-XXXX:");
        String input = sc.nextLine();
        String result = convertFormat(input);
        System.out.println("Converted format: " + result);
    }
}

