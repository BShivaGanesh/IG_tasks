package day_6_task3;
import java.util.Scanner;

public class Test1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter array size:");
		int n = sc.nextInt();
		int[] a= new int[n];
		System.out.println("Enter array elements:");
		for(int i=0;i<n;i++) {
			a[i]= sc.nextInt();
		}
		int res = findMaxDistance(a,n);
		System.out.println(res);

	}
	static int findMaxDistance(int[] a, int n) {
		int l=0;
		int maxDiff = 0,idx=0;
		for(int i=1;i<n-1;i++) {
			if(a[i]>l) {
				l=a[i];
				if(Math.abs(a[i]-a[i-1])>maxDiff) {
					maxDiff = Math.abs(a[i]-a[i-1]);
					idx=i;
				}
				else if(Math.abs(a[i]-a[i+1])>maxDiff) {
					maxDiff = Math.abs(a[i]-a[i+1]);
					idx=i;
				}
			}
		}
		return idx;
	}

}
