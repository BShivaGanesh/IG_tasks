package day_6_task3;
import java.util.*;

public class Test {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter string:");
        String str = sc.nextLine();  
        String res = getCapitalized(str);
        System.out.println("Capitalized String: " + res);
    }

    static String getCapitalized(String str) {
        String[] words = str.split(" "); 
        StringBuilder sb = new StringBuilder();
        for (String word : words) {
            if (word.length() > 0) {
                sb.append(word.substring(0, 1).toUpperCase() + word.substring(1).toLowerCase() + " ");
            }
        }
        return sb.toString().trim();
    }
}
