package day_6_task3;

import java.util.Scanner;

public class Test6 {

    public static int calculateWordSum(String sentence) {
        String[] words = sentence.split(" ");
        if (words.length == 0) {
            return 0; 
        }
        String firstWord = words[0];
        String lastWord = words[words.length - 1];
        if (firstWord.equals(lastWord)) {
            return firstWord.length();
        } else {
            return firstWord.length() + lastWord.length();
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a sentence:");
        String sentence = sc.nextLine(); 
        int result = calculateWordSum(sentence); 
        System.out.println(result); 
    }
}

