package day_6_task1;

import java.util.HashSet;

public class Test {
    public static void main(String[] args) {
      
        Address address1 = new Address("1234 Elm St", "Some City", "Some State", "12345");
        Address address2 = new Address("5678 Oak St", "Other City", "Other State", "67890");

        Student student1 = new Student("John", "Doe", 20, address1);
        Student student2 = new Student("Jane", "Doe", 22, address2);
        Student student3 = new Student("John", "Doe", 25, address1); 
        Student student4 = new Student("John", "Doe", 21, address2);

        HashSet<Student> students = new HashSet<>();
        students.add(student1);
        students.add(student2);
        students.add(student3); 
        students.add(student4); 

        for (Student student : students) {
            System.out.println(student);
        }
    }
}

