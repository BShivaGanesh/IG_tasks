package day_6_task2;

import java.util.*;

class Movie implements Comparable<Movie> {
    String name;
    String language;
    String releaseDate;
    String director;
    String producer;
    int duration;
    public Movie(String name, String language, String releaseDate, String director, String producer, int duration) {
        this.name = name;
        this.language = language;
        this.releaseDate = releaseDate;
        this.director = director;
        this.producer = producer;
        this.duration = duration;
    }
    public String getName() {
        return name;
    }
    public String getLanguage() {
        return language;
    }
    public String getDirector() {
        return director;
    }
    public int getDuration() {
        return duration;
    }
    @Override
    public int compareTo(Movie otherMovie) {
        return this.language.compareTo(otherMovie.language);
    }
    @Override
    public String toString() {
        return "Movie Name: " + name + ", Language: " + language + ", Release Date: " + releaseDate +
               ", Director: " + director + ", Producer: " + producer + ", Duration: " + duration + " minutes";
    }
}
