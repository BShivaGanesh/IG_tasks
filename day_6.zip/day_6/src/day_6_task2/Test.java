package day_6_task2;
import java.util.*;

public class Test {
    public static void main(String[] args) {
        MovieSorter movieSorter = new MovieSorter();
        List<Movie> movieList = movieSorter.createMovieSet();
        System.out.println("Movies before sorting:");
        movieList.forEach(System.out::println);
        movieSorter.sortByLanguage(movieList);
        System.out.println("\nMovies sorted by Language:");
        movieList.forEach(System.out::println);
        movieSorter.sortByDirector(movieList);
        System.out.println("\nMovies sorted by Director:");
        movieList.forEach(System.out::println);
        movieSorter.sortByDuration(movieList);
        System.out.println("\nMovies sorted by Duration:");
        movieList.forEach(System.out::println);
    }
}
