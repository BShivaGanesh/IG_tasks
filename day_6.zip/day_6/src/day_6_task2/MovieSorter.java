package day_6_task2;
import java.util.*;

class MovieSorter {
    public List<Movie> createMovieSet() {
        List<Movie> movieList = new ArrayList<>();
        movieList.add(new Movie("bahubali", "telugu", "2010-07-16", "rajamouli", "rana", 200));
        movieList.add(new Movie("uri", "hindi", "2019-05-30", "kishi", "vicky kaushal", 122));
        movieList.add(new Movie("evil dead", "english", "2001-04-25", "puri", "dil raju", 143));
        movieList.add(new Movie("arjun reddy", "telugu", "1995-10-20", "vijay", "devarkonda", 156));
        return movieList;
    }
    public void sortByLanguage(List<Movie> movieList) {
        Collections.sort(movieList); 
    }
    public void sortByDirector(List<Movie> movieList) {
        movieList.sort(Comparator.comparing(Movie::getDirector));
    }
    public void sortByDuration(List<Movie> movieList) {
        movieList.sort(Comparator.comparingInt(Movie::getDuration));
    }
}