package day_6_task4;

import java.util.Comparator;
import java.util.TreeSet;

public class Test {
    public static void main(String[] args) {
        TreeSet<Employee> employeesByEmpid = new TreeSet<>();
        employeesByEmpid.add(new Employee(101, "shiva", "ganesh"));
        employeesByEmpid.add(new Employee(103, "b", "shiva"));
        employeesByEmpid.add(new Employee(102, "ganesh", "b"));
        employeesByEmpid.add(new Employee(104, "java", "spring"));
        employeesByEmpid.add(new Employee(105, "bharath", "m"));
        System.out.println("Employees sorted by empid:");
        for (Employee emp : employeesByEmpid) {
            System.out.println(emp);
        }
        TreeSet<Employee> employeesByFirstname = new TreeSet<>(Comparator.comparing(Employee::getFirstname));
        employeesByFirstname.add(new Employee(101, "shiva", "ganesh"));
        employeesByFirstname.add(new Employee(103, "b", "shiva"));
        employeesByFirstname.add(new Employee(102, "ganesh", "b"));
        employeesByFirstname.add(new Employee(104, "java", "spring"));
        employeesByFirstname.add(new Employee(105, "bharath", "m"));
        System.out.println("\nEmployees sorted by firstname:");
        for (Employee emp : employeesByFirstname) {
            System.out.println(emp);
        }
    }
}

