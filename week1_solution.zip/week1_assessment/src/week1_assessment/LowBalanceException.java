package week1_assessment;

public class LowBalanceException extends Exception {
    public LowBalanceException(String message) {
        super(message);
    }
}
