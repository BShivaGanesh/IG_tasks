package week1_assessment;

public class AccountTest {
    public static void main(String[] args) {
        try {
            AccountService accountService = new AccountService();
            Account account1 = new Account(101, "shiva", "SAVINGS", 1500f);
            Account account2 = new Account(102, "ganesh", "CURRENT", 6000f);
            Account account3 = new Account(103, "BSG", "SAVINGS", 1020f);
            Account account4 = new Account(104, "SG", "SAVINGS", 10000f);
            Account account5 = new Account(105, "BS", "CURRENT", 50000f);
            accountService.addAccount(account1);
            accountService.addAccount(account2);
            accountService.addAccount(account3);
            accountService.addAccount(account4);
            accountService.addAccount(account5);
           accountService.deposit(101, 500f);
           accountService.withdraw(102, 1000f);
            System.out.println("Balance in Account 101: " + accountService.getBalance(101));
            System.out.println("Balance in Account 102: " + accountService.getBalance(102));
            System.out.println("Balance in Account 102: " + accountService.getBalance(103));
            System.out.println("Balance in Account 101: " + accountService.getBalance(104));
            System.out.println("Balance in Account 102: " + accountService.getBalance(105));
          accountService.deposit(101, -200f); 
           accountService.withdraw(103, 1000f); 
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}

