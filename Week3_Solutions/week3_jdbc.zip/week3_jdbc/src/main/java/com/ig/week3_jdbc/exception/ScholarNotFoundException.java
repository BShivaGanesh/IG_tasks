package com.ig.week3_jdbc.exception;

public class ScholarNotFoundException extends Exception{
	public ScholarNotFoundException(String msg){
		super(msg);
	}
}
