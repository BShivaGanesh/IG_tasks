package com.ig.week3_jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.ig.week3_jdbc.exception.ScholarNotFoundException;
import com.ig.week3_jdbc.model.Scholar;
import com.ig.week3_jdbc.util.DbUtil;

public class ScholarsDaoImpl implements ScholarsDao{

	@Override
	public List<Scholar> getAllScollars() throws Exception{
		ArrayList<Scholar> l = new ArrayList<>();
		Connection con = DbUtil.getConnection();
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("select * from Scholar");
		while(rs.next()) {
			Scholar s = new Scholar();
			s.setRollno(rs.getInt(1));
			s.setName(rs.getString(2));
			s.setEmail(rs.getString(3));
			s.setMobileno(rs.getString(4));
			l.add(s);
		}
		return l;
	}

	@Override
	public Scholar getScholarById(Integer id) throws Exception {
		Connection con = DbUtil.getConnection();
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("select * from Scholar where rollno="+id);
		if(rs.next()) {
			Scholar s = new Scholar();
			s.setRollno(rs.getInt(1));
			s.setName(rs.getString(2));
			s.setEmail(rs.getString(3));
			s.setMobileno(rs.getString(4));
			return s;
		}
		else {
			throw new ScholarNotFoundException("No scholar with that id");
		}
		
	}

	@Override
	public boolean updateScholarEmail(Integer id, String new_email) throws Exception {
		Connection con = DbUtil.getConnection();
		PreparedStatement pst = con.prepareStatement("update Scholar set email = ? where rollno = ?");
		 pst.setString(1,new_email);
		 pst.setInt(2,id);
		 return pst.executeUpdate()>0;
	}

	@Override
	public boolean deleteScholarById(Integer id) throws Exception {
		// TODO Auto-generated method stub
		Connection con = DbUtil.getConnection();
		PreparedStatement pst = con.prepareStatement("delete from Scholar where rollno=?");
		pst.setInt(1, id);
		return pst.executeUpdate()>0;
	}

	@Override
	public void addScholar(Scholar p) throws Exception {
		// TODO Auto-generated method stub
		Connection con = DbUtil.getConnection();
		PreparedStatement pst = con.prepareStatement("insert into Scholar values(?,?,?,?)");
		pst.setInt(1, p.getRollno());
		pst.setString(2, p.getName());
		pst.setString(3, p.getEmail());
		pst.setString(4, p.getMobileno());
		pst.execute();
		
	}

}

