package com.ig.week3_jdbc.service;

import java.util.List;

import com.ig.week3_jdbc.dao.ScholarsDao;
import com.ig.week3_jdbc.dao.ScholarsDaoImpl;
import com.ig.week3_jdbc.model.Scholar;


public class ScholarsServiceImpl implements ScholarsService{
	ScholarsDao s ;
	@Override
	public List<Scholar> getAllScollars() throws Exception {
		 s = new ScholarsDaoImpl();
		 return s.getAllScollars();	
	}
	@Override
	public Scholar getScholarById(Integer id) throws Exception {
		// TODO Auto-generated method stub
		s = new ScholarsDaoImpl();
		return s.getScholarById(id);
	}
	@Override
	public boolean updateScholarEmail(Integer id, String new_email) throws Exception {
		// TODO Auto-generated method stub
		return s.updateScholarEmail(id, new_email);
	}
	@Override
	public boolean deleteScholarById(Integer id) throws Exception {
		// TODO Auto-generated method stub
		return s.deleteScholarById(id);
	}
	@Override
	public void addScholar(Scholar sch) throws Exception {
		// TODO Auto-generated method stub
		s.addScholar(sch);
	}

}
