package com.ig.week3_jdbc.model;

public class Scholar {
	Integer rollno;
	String name;
	String email;
	String mobileno;
	public Integer getRollno() {
		return rollno;
	}
	public void setRollno(Integer rollno) {
		this.rollno = rollno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	@Override
	public String toString() {
		return "Scholar [rollno=" + rollno + ", name=" + name + ", email=" + email + ", mobileno=" + mobileno + "]";
	}
	

}
