package com.ig.week3_jdbc.dao;

import java.util.List;

import com.ig.week3_jdbc.model.Scholar;

public interface ScholarsDao {
	public List<Scholar> getAllScollars() throws Exception;
	public Scholar getScholarById(Integer id) throws Exception;
	public boolean updateScholarEmail(Integer id , String new_email) throws Exception;
	public boolean deleteScholarById(Integer id) throws Exception;
	public void addScholar(Scholar p) throws Exception;
}
