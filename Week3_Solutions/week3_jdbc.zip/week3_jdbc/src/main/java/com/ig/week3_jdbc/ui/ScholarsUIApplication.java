package com.ig.week3_jdbc.ui;

import java.util.Scanner;

import com.ig.week3_jdbc.model.Scholar;
import com.ig.week3_jdbc.service.ScholarsService;
import com.ig.week3_jdbc.service.ScholarsServiceImpl;

public class ScholarsUIApplication {
	public static void main(String[] args) throws Exception{
		Scanner sc = new Scanner(System.in);
		ScholarsService s = new ScholarsServiceImpl();
		printLine();
		System.out.println("getting all scholars");
		s.getAllScollars().stream().forEach(x -> System.out.println(x));
		printLine();
		System.out.println("getting  scholar by id");
		System.out.println("Enter id :");
		Integer id = sc.nextInt();
		System.out.println(s.getScholarById(id));
		printLine();
		System.out.println("update scholar email");
		System.out.println("Enter id :");
		Integer id1 = sc.nextInt();
		sc.nextLine();
		System.out.println("Enter new email :");
		String new_email = sc.next();
		System.out.println(s.updateScholarEmail(id1, new_email));
		printLine();
		System.out.println("getting all scholars");
		s.getAllScollars().stream().forEach(x -> System.out.println(x));
		printLine();
		System.out.println("delete scholar by id");
		System.out.println("Enter id :");
		Integer id2 = sc.nextInt();
		System.out.println(s.deleteScholarById(id2));
		printLine();
		System.out.println("getting all scholars");
		s.getAllScollars().stream().forEach(x -> System.out.println(x));
		printLine();
		System.out.println("enter scholar details:");
		System.out.println("Enter id :");
		Integer id3 = sc.nextInt();
		System.out.println("Enter name :");
		String name = sc.next();
		System.out.println("Enter email :");
		String email = sc.next();
		System.out.println("Enter mobile number :");
		String mobileno = sc.next();
		Scholar sch = new Scholar();
		sch.setRollno(id3);
		sch.setName(name);
		sch.setEmail(email);
		sch.setMobileno(mobileno);
		s.addScholar(sch);
		printLine();
		System.out.println("getting all scholars");
		s.getAllScollars().stream().forEach(x -> System.out.println(x));
		printLine();
		
		
		
	}
	static void printLine() {
		System.out.println("================================");
	}
	

}
