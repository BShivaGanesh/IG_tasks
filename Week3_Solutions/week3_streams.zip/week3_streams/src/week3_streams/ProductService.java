package week3_streams;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

class ProductService {
    private List<Product> products;

    public ProductService(List<Product> products) {
        this.products = products;
    }

    public Optional<Product> getHighestPricedProduct() {
        return products.stream().max(Comparator.comparingDouble(p -> p.price));
    }

    public Optional<Product> getLowestPricedProduct() {
        return products.stream().min(Comparator.comparingDouble(p -> p.price));
    }

    public List<Product> getExpiredProducts() {
        return products.stream()
                .filter(p -> p.expiryDate.isBefore(LocalDate.now()))
                .collect(Collectors.toList());
    }

    public List<String> getProductsExpiringSoon() {
        LocalDate today = LocalDate.now();
        return products.stream()
                .filter(p -> !p.expiryDate.isBefore(today) && p.expiryDate.isBefore(today.plusDays(10)))
                .map(p -> p.name)
                .collect(Collectors.toList());
    }

    public Map<String, Long> getProductTypeCount() {
        return products.stream()
                .collect(Collectors.groupingBy(p -> p.type, Collectors.counting()));
    }

    public Map<String, Long> getSupplierProductCount() {
        return products.stream()
                .collect(Collectors.groupingBy(p -> p.supplier.sname, Collectors.counting()));
    }
}

