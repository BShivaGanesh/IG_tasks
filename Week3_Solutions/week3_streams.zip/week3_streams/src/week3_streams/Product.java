package week3_streams;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

class Product {
    @Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", type=" + type + ", qty=" + qty + ", price=" + price
				+ ", expiryDate=" + expiryDate + ", supplier=" + supplier + "]";
	}

	Integer id;
    String name;
    String type; 
    Double qty;
    Double price;
    LocalDate expiryDate;
    Supplier supplier;

    public Product(Integer id, String name, String type, Double qty, Double price, LocalDate expiryDate, Supplier supplier) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.qty = qty;
        this.price = price;
        this.expiryDate = expiryDate;
        this.supplier = supplier;
    }
}
