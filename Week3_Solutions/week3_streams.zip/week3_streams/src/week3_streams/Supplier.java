package week3_streams;

class Supplier {
    Integer id;
    String sname;

    public Supplier(Integer id, String sname) {
        this.id = id;
        this.sname = sname;
    }

	@Override
	public String toString() {
		return "Supplier [id=" + id + ", sname=" + sname + "]";
	}
}
