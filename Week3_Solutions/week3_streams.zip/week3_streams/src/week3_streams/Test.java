package week3_streams;

import java.time.LocalDate;
import java.util.*;

public class Test {
    public static void main(String[] args) {
        Supplier supplier1 = new Supplier(1, "Supplier A");
        Supplier supplier2 = new Supplier(2, "Supplier B");

        List<Product> products = Arrays.asList(
                new Product(1, "Milk", "dairy", 2.0, 50.0, LocalDate.now().plusDays(5), supplier1),
                new Product(2, "Rice", "pulses", 5.0, 80.0, LocalDate.now().plusDays(15), supplier1),
                new Product(3, "Salt", "spices", 1.0, 20.0, LocalDate.now().minusDays(2), supplier2),
                new Product(4, "Oil", "oils", 3.0, 150.0, LocalDate.now().plusDays(8), supplier1),
                new Product(5, "Chips", "snacks", 1.5, 40.0, LocalDate.now().minusDays(5), supplier2)
        );

        ProductService productService = new ProductService(products);

        System.out.println("Highest Priced Product: " + productService.getHighestPricedProduct().orElse(null).toString());
        System.out.println("Lowest Priced Product: " + productService.getLowestPricedProduct().orElse(null).toString());
        System.out.println("Expired Products: " + productService.getExpiredProducts().toString());
        System.out.println("Products Expiring in Next 10 Days: " + productService.getProductsExpiringSoon());
        System.out.println("Product Type Count: " + productService.getProductTypeCount());
        System.out.println("Supplier Product Count: " + productService.getSupplierProductCount());
    }
}

